Ce paramètre détermine dans quelles perspectives les animations des éléments seront jouées.
"Toutes les perspectives" permettra toujours aux animations de jouer,
"Première personne" ne jouera les animations qu'à la première personne et
"Troisième/Seconde personne" jouera les animations uniquement lorsqu'il ne s'agit pas de la première personne.