The content text of the toast
