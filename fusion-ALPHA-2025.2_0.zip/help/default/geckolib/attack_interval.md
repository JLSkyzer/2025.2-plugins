This determines how long the attack animation of your entity keeps playing.
If you set this value higher than how long the animation lasts, it will play again after finishing.