If it is enabled, the color of the item will be removed by right-clicking a cauldron that has water in it \
\
This option works better with items that stack up to 1