If it is enabled, the color of the item will be removed by right-clicking a cauldron that has lava in it \
\
This option works better with items that stack up to 1 \
\
NOTE: A cauldron that as lava in it will not be reduced by right-clicking on it (unlike water and powder snow)