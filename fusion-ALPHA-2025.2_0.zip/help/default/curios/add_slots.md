If this checked, this bauble item will add new curios slots.
The type of those slots is determined by the type of slot the bauble goes in.