Este parámetro determina la cantidad de ticks que tardará la entidad en pasar de una animación a otra.
Establecer este valor más alto hará que la transición sea más suave, mientras que establecerlo más bajo reducirá la suavidad.
Para desactivar completamente las transiciones, establece este valor a cero.