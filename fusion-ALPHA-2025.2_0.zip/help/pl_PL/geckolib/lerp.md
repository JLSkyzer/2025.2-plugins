Ten parametr określa liczbę ticków potrzebnych bytowi do przejścia z jednej animacji do drugiej.
Ustawienie wyższej wartości sprawi, że przejście będzie płynniejsze, a ustawienie niższej spowoduje zmniejszenie płynności.
Aby całkowicie wyłączyć przejścia, ustaw tę wartość na zero.