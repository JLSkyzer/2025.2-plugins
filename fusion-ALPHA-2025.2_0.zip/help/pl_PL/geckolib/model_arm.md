To będzie nazwa używana podczas wyszukiwania grupy modeli do wyłączenia i zastąpienia ramieniem gracza.
To ramię będzie miało wtedy animacje, które ma grupa modeli.
Jeśli określona grupa modeli nie istnieje, ramię nie będzie wyświetlane.