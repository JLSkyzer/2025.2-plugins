This determined how big or small the entity's bounding box will be.
When changing the entity's scale, this should be changed too otherwise the bounding box will stay as the default size.