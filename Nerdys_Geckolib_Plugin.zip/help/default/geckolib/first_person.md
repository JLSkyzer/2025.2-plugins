When this option is checked, the model groups specified below will be replaced by player arms.
These arms will only be rendered on the screen in first person and will not be part of the model.