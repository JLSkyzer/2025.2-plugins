This is the animation that will play while the entity is walking, and no other animation is active.
If the entity has a flying animation, this will only play while the entity is walking on the ground.