This parameter determines the amount of ticks that it will take for the entity to transition from one animation to another.
Setting this value higher will make the transition smoother, while setting it lower will lower the smoothness.
To completely disable transitions, set this value to zero.