GeckoLib中盔甲模型的纹理。
