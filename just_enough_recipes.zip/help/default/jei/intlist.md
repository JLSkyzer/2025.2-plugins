If enabled, you will need to specify how much of each ingredient you define will be required to craft the recipe.
These ingredient counts will appear in the JEI window and will be provided to you by using
the procedure block provided under the JEI procedure category.