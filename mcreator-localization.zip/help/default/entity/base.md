A Vanilla entity AI to make an entity like a Vanilla one. 

It will also override some parameters like the drops.

Usually this parameter should be avoided and left default.