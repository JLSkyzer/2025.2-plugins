This parameter controls maximal size of the stack that can be placed in entity's internal inventory slots.

Keep in mind that the smaller number between this parameter and max item stack size 
determines the actual max stack size.