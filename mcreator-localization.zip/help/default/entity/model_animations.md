Here you can specify animations that this entity can play and the conditions when animations happen.

We recommend using Synced data to provide data for animation conditions, as the condition is client-side
only, but data for toggling animations is usually not client-side.

Existing model animations specified in model file or during model file import will also
play alongside animations specified here.