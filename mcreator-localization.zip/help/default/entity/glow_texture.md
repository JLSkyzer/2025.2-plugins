Glow texture will be used to define mob glowing layer. More bright texture areas will
result in these parts of the mob to glow more.