When this condition is false, the entity will not be pushed by fluids. This is usually desired when making a water entity.

The default value for living entities is true.