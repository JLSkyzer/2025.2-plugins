Checking this parameter makes the entity a water entity.

Enabling this parameter will make the entity have a water-type navigator, 
water motion controller, and allow world spawner to spawn it in fluids.

This will not make entity spawn in fluids.