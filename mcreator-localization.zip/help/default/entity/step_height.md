Sets the step height of the entity.

Most normal living entities have a step height of 0.6, while rideable entities such as horses have a step height of 1.