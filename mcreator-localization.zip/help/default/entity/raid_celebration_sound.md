This sound will be played if the entity wins the raid.

Each Raider will play their own celebratory sound at the end of the raid.

The sound is selectable if the entity is a raider type.