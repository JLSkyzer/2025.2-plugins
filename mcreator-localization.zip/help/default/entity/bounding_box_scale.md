This feature allows you to control the size of your entity's collision box.

To scale entities in-game appearance, use the "Model visual scale" parameter.