Here you can set how many times the entity will spawn in each raid wave.

Depending on the difficulty there will be a certain number of waves:

* Peaceful: 0
* Easy: 3
* Normal: 5
* Hard: 7

The number of entities generated per raid wave are selectable if the entity is a raider type.