If ticked, this mob will despawn upon the player moving far away enough (default behaviour for most mobs).
 
Turn this off for bosses and summonable mobs to stop them despawning.