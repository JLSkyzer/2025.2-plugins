If checked, your entity will attack with a projectile (similar to the Skeleton). You can select:
* Your own projectile from the list (or use default - arrow);
* The interval between ranged attacks (in ticks);
* The radius in which the entity will still target another entity after that entity leaves its follow range.