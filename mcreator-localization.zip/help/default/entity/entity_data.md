Add custom variables to your custom entity. 

These variables are synchronized between client side and server side, 
so one of them can be used, for example, to change the texture of your entity.