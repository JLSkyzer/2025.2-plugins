The items used to breed the entity with another one if breedable parameter is enabled.

To make the animal actually breed, make sure to add appropriate AI tasks from teh "Animal tasks" category.