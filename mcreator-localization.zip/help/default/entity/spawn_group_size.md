The minimum and maximum specified here set the size of groups that the entity will spawn in. 

Keep in mind that entities will struggle to spawn in groups of over 20 (such groups will spawn more rarely).