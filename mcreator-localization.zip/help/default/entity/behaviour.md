Living entity set to Mob will be able to attack, while a living entity set to Creature will be passive.

A Raider is a monster that spawns in a raid.

This parameter is overridden by the AI base when used.

Keep in mind that if you select Creature type here, attack AI types will make the entity crash the game in most cases.