This parameter controls how many blocks far the entity is tracked by the players.

Setting this parameter to 0 will disable rendering and collisions of the entity entirely.