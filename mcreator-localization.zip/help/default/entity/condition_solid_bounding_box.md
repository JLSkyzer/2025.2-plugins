If this feature is enabled, the entity's bounding box will act similar to 
the bounding box of a block(solid collision).

Used by boats and shulkers in vanilla Minecraft.