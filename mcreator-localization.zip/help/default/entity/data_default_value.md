This is the default value of the entity's variable.

* **Logic**: _true_ or _false_
* **Number**: Can go from the maximal negative limit to the maximal positive limit of an integer
* **String**: Text/string value