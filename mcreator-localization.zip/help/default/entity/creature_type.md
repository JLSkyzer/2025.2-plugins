Allows you to set a creature's type, causing certain changes. 
* **Undead** take extra damage from the Smite enchantment, are healed by Harming and harmed by Healing, 
and are unaffected by Poison or Regeneration. 
* **Arthropods** take extra damage from the Bane of Arthropods enchantment. 
* **Illager** does not seem to have any effect.
* **Water** take extra damage from the Impaling enchantment. 