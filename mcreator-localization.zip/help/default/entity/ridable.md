These parameter enables the player to mount to this entity.

You can enable optional controlls too.