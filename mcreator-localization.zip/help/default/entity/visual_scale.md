This feature allows you to control the visual model size of the entity in-game.

To scale entity's collision box, use the "Bounding box scale" parameter.