While the returned value is true, the entity will be transparent.
While a player is in spectator mode, they meet this condition.