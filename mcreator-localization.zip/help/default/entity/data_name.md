This parameter defines the name of this variable.

Mainly used with procedure blocks to get or set its value.