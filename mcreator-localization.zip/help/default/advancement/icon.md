The icon shows in the advancements tab.

If this is a root parent then it will be the advancement icon too.

Only items are supported here. Blocks without item can not be shown as icon.