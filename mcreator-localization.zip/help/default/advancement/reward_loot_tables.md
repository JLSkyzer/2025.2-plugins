The player will receive some items from the selected loot table defined in this field 
when the advancement is completed.