This is the type of achievement

* Task is a basic achievement type and is most common.
* Goal is a long term goal which you strive to achieve.
* Challenge is to test a player or challenge them to something.