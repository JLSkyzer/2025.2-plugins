Show the advancement on the top right of the screen when the player completes the advancement.
