Use this procedure trigger to specify additional tool drop/harvest condition.
Both vanilla and custom harvest condition need to be met for the block to be harvested using this tool.

If this procedure returns false, the tool will not harvest the block drop.