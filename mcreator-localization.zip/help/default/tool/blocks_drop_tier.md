This is the tier this tool is. It defines what blocks it can successfully harvest.

If you want more control such as custom tiers and harvest rules,
use custom procedure for an additional drop condition.