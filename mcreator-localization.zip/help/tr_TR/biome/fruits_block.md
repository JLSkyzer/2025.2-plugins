Bu parametre, özel ağaçların etkinleştirilmesi durumunda Orman ağaçları ile Kakao Çekirdekleri gibi meyveler için kullanılan bloğu kontrol eder.

Ağaç meyvelerini devre dışı bırakmak için hava bloğunu seçin.