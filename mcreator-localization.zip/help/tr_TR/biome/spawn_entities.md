Biyomunuzun içinde doğal olarak ortaya çıkacak varlıkları seçin.

Sadece pasif veya düşman çeteleri seçin. Burada oyuncu veya özel varlıkları seçmeyin, çünkü bu bu tür varlıkları ortaya çıkarmaya çalışırken dünyanın çökmesine neden olur.