Kıtasallık, biyomun kıyıdan ne kadar uzakta olduğunu kontrol eder. Daha küçük değerler kıyıya daha yakın biyomlar anlamına gelirken, daha yüksek değerler biyomlar kıyıdan daha uzakta ve daha yüksekte (örneğin dağlar) anlamına gelir.

Benzer kıtasallığa sahip biyomlar birbirine daha yakın oluşacaktır ve üretilirken dünyada aynı yer için rekabet edeceklerdir. Çok benzer değerler bazı biyomların üretilmemesine neden olacaktır.

-2 ila 2 arasındaki değerler geçerli olsa da, vanilya biyomları yalnızca aşağıdaki aralıktaki değerleri kullanır -1'den 1'e kadar.

Dünya üzerindeki vanilya biyomları bu değer aralıklarını kullanır:

* Derin okyanus: -1,05 ila -0,455
* Okyanus: -0.455 ila -0.19
* Sahil: -0,19 ila -0,11
* İç kesim: -0,11 ila 0,55
* İç kesimlere yakın: -0,11 ila 0,03
* Orta iç kesim: 0,03 ila 0,3
* Uzak iç kesimler: 0,3 ila 1,0