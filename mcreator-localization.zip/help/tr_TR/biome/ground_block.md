Bu parametre biyomun üst katmanındaki bloğu kontrol eder.

Genel olarak, burada çoğu biyom için vanilya veya özel çim kullanılır.

Bu blok, bitkiler için `minecraft:dirt` Blokları etiketlerinde etiketlenmelidir ve ağaçların yüzeyde düzgün bir şekilde oluşması için.

Şu tarz karmaşık blokları kullanmaktan kaçının:

* şeffaf bloklar
* tam küp olmayan bloklar
* entity varlığına, NBT etiketlerine veya envantere sahip bloklar
* POI olarak kullanılan bloklar
* işaretlenen bloklar

Bu tür bloklar kullanırsanız, worldgen yavaş olacaktır ve yüklenen dünya ciddi şekilde gecikebilir.