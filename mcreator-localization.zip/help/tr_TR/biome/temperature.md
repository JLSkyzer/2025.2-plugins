Bu parametre biyomun iklim sıcaklığını kontrol eder.

0.0 Karlı Tundra gibidir ve 2.0 Çöl gibidir.

* 0,15'ten küçük değerler, çöküş gerçekleşirken özel biyomu kar yapar
* 0,15 ile 1,5 arasındaki değerler biyomu yağışlı hale getirir
* 1,5'ten büyük değerler biyomu kuru hale getirecektir (örneğin yağmur yağmaz, çöller)