Bu parametre bu biyomdaki çimlerin rengini kontrol eder.

Bu parametre diğer bitkilerin (yaprakların) rengini de değiştirir.