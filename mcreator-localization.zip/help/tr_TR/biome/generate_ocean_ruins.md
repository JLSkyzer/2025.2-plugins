Biyomunuzda Okyanus Harabeleri olması için bu ayarı seçin.
* YOK: Hiçbir Okyanus kalıntısı oluşturulmayacaktır.
* SOĞUK: Taştan yapılmış Okyanus Kalıntıları oluşturulacak
* SICAK: Kumtaşından yapılmış Okyanus Harabeleri oluşturulacak