Bu alan, Dünya yüzeyinin ne kadarının bu biyom tarafından kaplanacağına dair bir tahmin sağlar. Yalnızca biomelar için değerler - arasında ise düzgün çalışır. 1 ve 1 bu aralık olduğu için Dünya dışı biomelar kullanır.

Biyomunuzun Nether'da veya Dünyadışı mağaralarında kullanılması durumunda, bu tahmin geçerli değildir.

Özel bir boyutta biyomeları kullanılırken, kapsamı, o boyutun sahip olduğu biyom miktarına bağlıdır, ve biyom üretimi parametesi de biyom miktarına bağlıdır.