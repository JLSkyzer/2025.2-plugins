Parçacıkların ortaya çıkma olasılığı.

NOT: Bu değer kodda 100'e bölünür.