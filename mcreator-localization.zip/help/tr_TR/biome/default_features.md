Varsayılan özellikler önceden yapılandırılmış özellikleri (Minecraft özelliklerini) biyomunuzda kullanabilirsiniz.
