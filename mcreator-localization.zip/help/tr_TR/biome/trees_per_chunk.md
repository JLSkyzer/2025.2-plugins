Bu parametre, biyom parçası başına (seçtiğiniz türdeki) ağaç sayısını kontrol eder.

Ağaçları devre dışı bırakmak için "0"a ayarlayın.