Bu parametre katman kayasının altındaki yeraltı bloğunu kontrol eder.

Genellikle çoğu biyom için vanilya veya özel toprak kullanılır.

Bu blok, bitki ve ağaçların yüzeyde düzgün bir şekilde ortaya çıkması için `minecraft:dirt` Blokları etiketlerinde etiketlenmelidir.

Şu bloklar gibi karmaşık blokları kullanmaktan kaçının:

* şeffaf bloklar
* tam küp olmayan bloklar
* entity varlığına, NBT etiketlerine veya envantere sahip bloklar
* POI olarak kullanılan bloklar
* işaretlenen bloklar

Bu tür bloklar kullanırsanız, dünya oluşumu yavaş olur ve yüklenen dünya ciddi şekilde gecikebilir.