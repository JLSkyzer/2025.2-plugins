Bu parametre, oluşturulduğunda ağaç gövdesinin minimum yüksekliğini tanımlar.

Yalnızca özel ağaç tanımı seçildiğinde uygulanır.