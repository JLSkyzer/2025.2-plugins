Bu paremetre, sarmaşıkları değiştirmek için kullanılan bloğu kontrol eder.

Sarmaşıkların olmaması için hava bloğunu seçin.
