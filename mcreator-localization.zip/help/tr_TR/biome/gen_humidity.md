Bu parametre iklimi değil biyom oluşumunu kontrol eder.

Benzer neme sahip biyomlar birbirine daha yakın oluşacaktır ve üretilirken dünyada aynı yer için rekabet edeceklerdir. Çok benzer değerler bazı biyomların üretilmemesine neden olacaktır.

-2 ila 2 arasındaki değerler geçerli olsa da, vanilya biyomları yalnızca aşağıdaki aralıktaki değerleri kullanır -1'den 1'e kadar.

Dünya üzerindeki vanilya biyomları bu değer aralıklarını kullanır:

* -1.0 ila -0.35
* -0.35 ila -0.1
* -0.1 ila -0.1
* 0.1 ila -0.3
* 0.3 ila -1.0