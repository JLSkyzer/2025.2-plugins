Erozyon, arazinin ne kadar aşınmış olduğunu kontrol eder. Daha küçük değerler şu biyomları tanımlar genellikle daha düz dünya bölgelerinde üretilir.

Benzer erozyona sahip biyomlar birbirine daha yakın oluşacaktır ve üretilirken dünyada aynı yer için rekabet edeceklerdir. Çok benzer değerler bazı biyomların üretilmemesine neden olacaktır.

-2 ila 2 arasındaki değerler geçerli olsa da, vanilya biyomları yalnızca aşağıdaki aralıktaki değerleri kullanır -1'den 1'e kadar.

Dünya üzerindeki vanilya biyomları bu değer aralıklarını kullanır:

* -1.0 ila -0.78
* -0.78 ila -0.375
* -0.375 ila -0.2225
* -0.2225 ila -0.05
* 0.05 ila -0.45
* 0.45 ila -0.5
* 0.55 ila -1.0