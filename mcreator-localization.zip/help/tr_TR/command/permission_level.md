Oyuncunun, komutu yürütmek için en azından bu izin düzeyine sahip olması gerekir.

İzin gereksinimini de devre dışı bırakabilirsiniz. Bu durumda, belirli bir dünyada hileler kapatılsa bile komut çalışacaktır.

1 en temel izin düzeyidir ve 4 en yüksek izin düzeyidir (sunucu OP [yönetici] düzeyi).

Her izin düzeyinde hangi komutun yürütülebileceğini görmek için [bu sayfayı](https://mcreator.net/wiki/command-permission-levels) kontrol edin.