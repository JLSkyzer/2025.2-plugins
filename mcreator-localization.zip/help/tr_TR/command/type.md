Bu seçenek, komutun türünü ve nasıl/nerede kullanılabileceğini belirlemenizi sağlar.

* **STANDART**: Komut her yerde kullanılabilir. Bu yaygın/normal davranıştır (ör. `/give`).
* **SINGLEPLAYER_ONLY**: Komut yalnızca tek oyunculu dünyalarda mevcut olacaktır (ör. `/publish`).
* **MULTIPLAYER_ONLY**: Komut yalnızca çok oyunculu sunucularda kullanılabilir (ör. `/ban`).
* **CLIENTSIDE**: Komut yalnızca istemci tarafında olacaktır; bu, yalnızca istemcideki eylemlerin gerçekleştirilebileceği anlamına gelir.