Blok, bu mesleği icra eden köylüler tarafından çalışma bloğu olarak kullanılmaktadır.

İki mod aynı meslek bloğunu tanımlarsa veya başka bir mod POI'yi bu blokla birlikte kullanırsa başka bir özellik varsa, meslek çalışmayacaktır. Bu nedenle, tavsiye edilir kullanılan bloğun benzersiz olduğunu iki kez kontrol etmek için.

Dünyanın ilk oluşumunda yerleştirilen blokları veya dünyanın geneli tarafından yaygın olarak yerleştirilen blokları kullanmaktan kaçının, çünkü bu çok fazla uyarı verilmesine neden olabilir. kaydedilir ve ciddi performans sorunlarına neden olabilir.

Bu tür bloklara örnek olarak hava, toprak, taş, çimen, özel biyom blokları vb. verilebilir.