Bu parametre, seçilen meslek dokusu tarafından tanımlanan şapka türünü belirtir. Köylünün bu mesleği talep ettikten sonra kendi türüne göre tanımlanan şapkayı giymeye devam edip etmeyeceği:
* **Hiçbiri:** Tüm durumlarda;
* **Kısmi:** Köylünün başının tamamını kaplamadığı durumlarda;
* **Tam:** Hiçbir durumda.

Bu durum aşağıdaki tablo ile gösterilebilir (burada TH türe bağlı şapka ve PH meslek şapkasıdır):

| TH görünürlüğü | TH = Yok | TH = Kısmi | TH = Tam |
| -------------- |:--------:|:----------:|:--------:|
| PH = Yok       | Görünür  |  Görünür   | Görünür  |
| PH = Kısmi     | Görünür  |  Görünür   |  Gizli   |
| PH = Tam       |  Gizli   |   Gizli    |  Gizli   |