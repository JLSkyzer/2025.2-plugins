Bu parametre, iksir aktif olduğunda oyuncunun envanterinde görüntülenen simgeyi kontrol eder.

ÖNEMLİ: Doku adı elemanın kayıt adından farklıysa, dokunun bir kopyası oluşturulacaktır.