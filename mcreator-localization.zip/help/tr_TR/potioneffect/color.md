Şişelerin ve okun rengini seçin.

Öğeleri istemiyorsanız bu seçeneğe ihtiyacınız yoktur.