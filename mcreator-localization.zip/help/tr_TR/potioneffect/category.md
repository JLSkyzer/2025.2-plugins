Bu parametre efekt kategorisini belirler.

Kategoriler:

- **NÖTR**: etki oyuncu için ne kötü ne de iyidir, Parlama veya Kötü Alamet iksir etkileri gibi
- **ZARARLI**: etki oyuncu için kötüdür, Zehir veya Ani Hasar iksir etkileri gibi
- **FAYDALI**: etki oyuncu için iyidir, Yenilenme veya Anında Sağlık iksiri etkileri gibi