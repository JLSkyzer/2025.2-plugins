Bu parametre, boyutun gece-gündüz döngüsüne sahip üst dünyaya benzer bir şekilde tavan penceresine sahip olmasını sağlayacaktır.

Gök ışığının bloklar arasında yayılmadığını unutmayın, bu nedenle gök ışığına sahip nether boyutları hala karanlık olacaktır ve karanlık olmamak için Küresel ışık kaynağının etkinleştirilmesi gerekir.