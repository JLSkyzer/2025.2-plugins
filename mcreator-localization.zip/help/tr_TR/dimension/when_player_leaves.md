Prosedür, bir oyuncu boyuttan ayrıldığında yürütülecektir.
