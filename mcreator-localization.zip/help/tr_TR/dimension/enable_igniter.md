Entegre portal tetikleyicisi kullanmak için bu parametreyi işaretleyin. Bunun yerine özel bir portal tetikleyicisi kullanmayı planlıyorsanız bunun işaretini kaldırın.

Özel bir portal tetikleyicisi yapmak için yeni bir prosedür oluşturun ve 'Özel ateşleyici öğesi kullanarak bir boyuta portal oluştur' yerleşik şablonunu kullanın.