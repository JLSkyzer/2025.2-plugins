Bu boyut için Nether benzeri portalı etkinleştirmek için bu parametreyi işaretleyin.

Bunu devre dışı bırakabilir ve bu boyuta girmenin özel yolunu tanımlamak için prosedürleri kullanabilirsiniz.