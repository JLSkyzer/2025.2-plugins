Oluşturma mesafesi büyük değerlere ayarlanmış olsa bile boyutta yoğun sisi etkinleştirmek için bu parametreyi işaretleyin. Bunun bir örneği Nether'deyken görülebilir.
