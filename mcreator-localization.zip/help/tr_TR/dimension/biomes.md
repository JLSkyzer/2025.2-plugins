Bu boyutta oluşturulacak biyomların listesi. Biyomlar, bitki türleri, ağaçlar, yapılar ve mob yumurtlama özellikleri gibi boyut bölgeleri için tüm özellikleri tanımlar.

Boyut, biyomları biyom özelliklerine göre eşit olarak dağıtacaktır.
