Boyutun ana bloğu, Dünyadaki Taş oranı gibi olsun.

Şunlar gibi karmaşık blokları kullanmaktan kaçının:

* saydam Küpler
* tam olmayan yarım küpler
* canlıların varlığına, NBT etkilerine veya envatere sahip küpler(bloklar)
* İlgi Noktası (POI) olarak kullanılan bloklar
* seçilen bloklar

Bu tür blokları kullanırsanız, oluşturduğunuz dünyanız yavaşlayacak ve yüklü dünya ciddi şekilde geç açılabilir.