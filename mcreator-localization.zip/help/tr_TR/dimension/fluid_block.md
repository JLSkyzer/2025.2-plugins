Göller için sıvı, Yerüstü Dünyası için Su ve Cehennem için lav gibi.

Şunlar gibi karmaşık blokları kullanmaktan kaçının:

* saydam bloklar
* tam küp olmayan bloklar
* entity tile, NBT etiketleri veya envanter içeren bloklar
* POI olarak kullanılan bloklar
* işaretli bloklar

Bu tür bloklar kullanırsanız, dünya oluşumu yavaş olur ve yüklenen dünya ciddi şekilde gecikebilir.