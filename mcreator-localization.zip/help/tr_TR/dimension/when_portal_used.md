Oyuncu bir blok üzerinde portal tetikleyicisini kullandığında prosedür çalıştırılacaktır.

Yordam, tetikleyici blokla etkileşime girmişse SUCCESS/CONSUME, etkileşim başarısız olmuşsa FAIL ve etkileşim olmamışsa PASS türünde bir eylem sonucu sağlamalıdır. Tetikleyici başarıyla bir portal oluşturduysa veya prosedür herhangi bir değer döndürmezse, eylem sonuç türü BAŞARILI olacaktır.