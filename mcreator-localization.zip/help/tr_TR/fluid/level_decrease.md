Bu parametre, yayıldığı her blok için bu sıvının seviyesinin ne kadar azaldığını belirler. Daha yüksek değerlerle, sıvı daha küçük bir alanı kaplayacaktır.

Bu değer Nether'daki su ve lav için 1, Overworld'deki lav için 2'dir.