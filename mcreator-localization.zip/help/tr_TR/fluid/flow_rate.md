Bu parametre, sıvının başka bir bloğa yayılması için kaç tik gerektiğini belirler. Bu değer ne kadar yüksekse sıvı daha yavaş hareket edecektir.

Varsayılan değerler su için 5, Yerüstü Dünyası'ndaki lav için 30 ve Cehennem'deki lav için 10'dur.