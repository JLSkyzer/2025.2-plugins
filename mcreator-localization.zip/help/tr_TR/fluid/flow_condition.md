Bu durum, sıvının belirli bir konumdan yayılıp yayılamayacağını belirler.

Bunun diğer özelliklerden de etkilendiğini unutmayın (yakındaki eğimler, katı bloklar vb.).