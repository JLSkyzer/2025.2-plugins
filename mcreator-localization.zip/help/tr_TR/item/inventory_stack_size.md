Bu parametre, dahili envanter yuvalarına yerleştirilebilecek maksimum yığın boyutunu kontrol eder.

Bu parametre ile maksimum öğe yığını boyutu arasındaki küçük sayının gerçek maksimum yığın boyutunu belirlediğini unutmayın.