Bu prosedür, oyuncu bu öğeyi kullanmayı bıraktığında (sağ tıklamayı bıraktığında) çağrılır.

Bu tetikleyici yalnızca öğenin kullanım süresi 0'dan fazlaysa çalışır.