GUI/envanterinizin sahip olduğu yuva sayısını seçin. En büyük yuva kimliğine 1 eklemeyi unutmayın.

Blok GUI'ye bağlıysa, bu değeri <0> GUI'deki en büyük yuva kimliği + 1</0> olarak ayarlayın