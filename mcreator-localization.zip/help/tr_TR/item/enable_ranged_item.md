Bu parametre etkinleştirildiğinde, öğe bir menzilli öğe haline gelecektir yaylar ve arbaletler gibi bir atış yapmasını sağlar.

Menzilli eşyanın çalışması için animasyonu yay veya benzerine ayarlayın ve eşya kullanım süresi için sıfır olmayan bir değer kullandığınızdan emin olun.

Menzilli öğe özelliğini kullanırsanız, öğe yalnızca gerekli öğe (cephane) oyuncunun envanterindeyse ateş edecektir. Bu, vanilla oklar veya özel bir nesnenin gerekli öğe parametresinde belirtilen öğe kullanıldığında oklardır.

Gerekli eşya sistemi olmadan bir mühimmat ateşlemek istiyorsanız, sağ tıklama prosedürü tetiğini ve ateş etme prosedürlerini kullanın.