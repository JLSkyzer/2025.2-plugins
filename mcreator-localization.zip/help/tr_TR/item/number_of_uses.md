Bu parametre öğenin dayanıklılığını (öğenin kaç kez kullanılabileceğini) kontrol eder.

Verilen öğede kullanım sayısı mekaniğini devre dışı bırakmak için bu değeri 0 olarak ayarlayın.

Referans için Vanilya değerleri:

* Altın: 32 kullanım
* Ahşap: 59 kullanım
* Taş: 131 kullanım
* Demir: 250 kullanım.
* Elmas: 1561 kullanım
* Netherite: 2031 kullanım
* Olta: 64 kullanım
* Çakmaktaşı ve çelik: 64 kullanım alanı
* Çubukta havuç: 25 kullanım
* Makas: 238 kullanım
* Üç başlı mızrak: 250 kullanım
* Crossbow: 326 kullanım
* Kalkan: 336 kullanım
* Yay: 384 kullanım
* Elitra: 432 kullanım