Bu parametre, öğenin bir çekimde ne kadar süre kullanılabileceğini kontrol eder.

Eğer öğe bir yiyecekse, bu değer oyuncunun yiyecekten bir öğe yemesi için gereken süreyi tik cinsinden tanımlar.