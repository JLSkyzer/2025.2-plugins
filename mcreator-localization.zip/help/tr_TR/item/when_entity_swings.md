Varlık öğeyi havada salladığında bir prosedürü tetikler.

Örneğin, havadaki öğenize sağ tıklarsanız, prosedür yürütülecektir.