Prosedür, bir oyuncu elinde bu öğe varken sağ tıkladığında yürütülür.

Bu prosedürün yalnızca varlık bu öğe ile havada sağ tıkladığında çağrılmasını istiyorsanız, “${l10n.t(“elementgui.common.event_right_clicked_block”)}” yordamı her zaman BAŞARI/SONUÇ döngüsü vermelidir.