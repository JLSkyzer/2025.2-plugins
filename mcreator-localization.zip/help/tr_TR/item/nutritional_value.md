Besin değeri, bu yiyeceğin oyuncuyu ne kadar beslediğidir.

1, bir yemek barının yarısıdır. 20 tam yemek barıdır.