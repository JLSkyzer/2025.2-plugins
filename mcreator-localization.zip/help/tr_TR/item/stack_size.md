Bu, bir yığına sığabilecek bu türdeki öğelerin maksimum sayısıdır.

Vanilya örneği: Ender İncilerinin yığın boyutu 16'dır.