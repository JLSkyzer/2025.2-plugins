Bu prosedür, seçilen prosedürün dönüş değerinin doğru olup olmadığını kontrol etmek için aralıklı öğe ateşlenmeden önce çağrılacaktır.

Ek koşulları devre dışı bırakmak için “${l10n.t(”condition.common.true“)}” ifadesini saklayın. Cephane kontrolleri bu durumda hala geçerlidir.