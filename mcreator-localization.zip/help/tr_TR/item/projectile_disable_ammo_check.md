Bu parametre etkinleştirildiğinde, menzilli öğe herhangi bir nesne olmasa bile ateş eder.

Özel menzilli öğe kullanım koşulu prosedürü işaretlenmişse bile yine de geçerlidir.