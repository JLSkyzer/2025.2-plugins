Bu parametre bu özelliğin adını kontrol eder. Yinelenen isimlere izin verilmez.

Vanilla Minecraft adına tüm öğeler için tanımlanmış bazı özellikler vardır, bu nedenle adları kullanılamaz.