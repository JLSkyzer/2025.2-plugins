Bu özel öğe özelliğinin değerini belirlemek için bir prosedür belirtin.

Bir varlık bu öğeye sahipse, sağlanan koordinatlar/dünya bu varlığın konumunu tanımlar.