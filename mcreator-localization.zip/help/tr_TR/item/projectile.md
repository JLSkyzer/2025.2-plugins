Bu, bu menzilli öğenin atabileceği madde türüdür.

Özel bir fırlatılabilen madde oluşturabilir ve kullanabilir ya da vanilla bir madde kullanabilirsiniz. Eğer vanilla bir cisim seçerseniz, onun değerleri burada belirtilen değerlerden daha yüksek önceliğe sahip olacaktır.