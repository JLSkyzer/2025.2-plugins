Bu, başarınızın listeleneceği ilerleme kısmıdır.

"No parent: root" seçeneğini kullanarak yeni bir başarı ağacı oluşturabilirsiniz. (Bu başarı ekranında yeni bir sekme açılacağı anlamına gelmektedir.).