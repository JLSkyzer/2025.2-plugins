Bunlar seçtiğiniz başarının olabileceği türlerdir:

* Task, basit bir başarı türüdür ve aralarında en yaygın olanıdır. Bunu kazanılması kolay başarılar için seçebilirsiniz.
* Goal, uzun soluklu ve başarmak için oyuncunun uğraşacağı başarımlardır.
* Challenge ise bir oyuncuyu test etmek veya ona bir konuda meydan okunmasıdır. Oyun içinde Mor yazıyla gösterilir.