Oyuncu ilerlemeyi tamamladığında ekranın sağ üst köşesinde ilerlemeyi göster.
