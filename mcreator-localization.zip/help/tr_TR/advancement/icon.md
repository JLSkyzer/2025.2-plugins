Bu icon başarı ekranında gözükür.

Eğer bu bir ebeveyn başarım olarak işaretlendiyse o zaman ilerleme simgeleride aynı olacaktır.

Burada yalnızca öğeler kabul edilir. Öğesi olmayan bloklar simge olarak gösterilemez.