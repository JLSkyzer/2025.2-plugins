Bitki türleri, bir bitkinin oyuncular tarafından ve dünya üretimi sırasında nereye yerleştirilebileceğini belirler. Statik bitkilerin her zaman (Kaba) Toprak, Podzol, Çimen ve Tarım Arazisi üzerinde kalabileceğini, yetiştirilebilir bitkilerin ise her zaman kendi üzerlerinde kalabileceğini unutmayın.

Tam bitki türü listesini [burada](https://mcreator.net/wiki/plant-types-list) bulabilirsiniz.