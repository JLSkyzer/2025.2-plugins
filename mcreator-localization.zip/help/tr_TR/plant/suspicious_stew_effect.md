Bu parametre, bu bitkiyle hazırlanmış şüpheli güveçlerin iksir etkisini belirler.

NOT: Şüpheli güveçleri yapabilmek için bitkiyi `minecraft:small_flowers` eşya etiketine eklemeniz gerekir.