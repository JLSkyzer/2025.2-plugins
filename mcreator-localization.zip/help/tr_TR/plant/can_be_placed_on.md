Üzerine bitkilerin yerleştirilebileceği blokların listesi.

NOT: Bitki türü yerleştirme koşulunu geçersiz kılar.