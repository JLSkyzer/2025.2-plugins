Bu parametre, bitkinizin haritalarda hangi renkte görüneceğini kontrol eder.

Varsayılan olarak ayarlanırsa, renk SOLGUN olacaktır.