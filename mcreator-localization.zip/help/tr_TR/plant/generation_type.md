Bu parametre bitkinizin ne sıklıkta üretileceğini kontrol eder. <0>Çim</0> olarak ayarlanırsa, bitki daha sık üretilir.

NOT: Bu sadece statik ve çift bitkileri etkiler.