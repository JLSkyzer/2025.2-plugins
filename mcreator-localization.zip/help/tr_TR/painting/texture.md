Bu parametre, bu resmin ne kadar yüksek oranda arttığını (blok birim cinsinden) kontrol eder.

ÖNEMLİ: Eğer doku adı, öğenin kayıt adından farklıysa, dokunun bir kopyası oluşturulacaktır.