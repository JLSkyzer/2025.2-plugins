Bu özelliğin oluşturulması için daha fazla koşula sahip olmak üzere mantıksal dönüş değeri olan bir prosedür ekleyin.

Bu koşul, özellik oluşturucudaki yerleştirme değiştiricilerinden SONRA kontrol edilir.

Erken dünya oluşturma sırasında bazı prosedür bloklarının bu tetikleyicide düzgün çalışmayabileceğini unutmayın.
