Bu ayar etkinleştirilirse, özellik doğal olarak oluşturulmaz ve yerleştirme ayarları yok sayılır.

Özellik yalnızca `/place` komutu kullanılarak, prosedürlerden veya diğer özellikler tarafından referans verildiğinde yerleştirilecektir.

NOT: Özellik yerleştirilirken ek üretim koşulu yine de kontrol edilecektir.