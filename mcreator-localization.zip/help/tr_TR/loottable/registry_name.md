Açılır listeye tıklayın ve ganimet tablosunun "kategorisini" seçin. Ganimet tablosu türünü tanımlamaz.

Bu sadece ganimet tablosu adlarını standartlaştırmak içindir. Örneğin blok yağma tabloları için blocks/registry_name kullanın.