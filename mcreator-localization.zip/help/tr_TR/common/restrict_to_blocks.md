Yumurtlamanın hangi blok(lar) da gerçekleşeceğini tanımlamak için bu alanı kullanın.

Liste boşsa bu seçenek devre dışı bırakılacak ve tüm bloklarda ortaya çıkabilecektir.