Yumurtlamanın gerçekleşeceği biyomları tanımlamak için bu alanı kullanın.

Liste boşsa herhangi bir biyom kısıtlaması belirlenmeyecek ve tüm biyomlarda yumurtlama meydana gelecektir.