Bu parametre, öğenizin yaratıcı modda nerede bulunabileceğini tanımlar.

Liste boşsa öğe hiçbir sekmeye eklenmez.