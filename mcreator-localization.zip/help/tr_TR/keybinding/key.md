Bu parametre, anahtar bağlama prosedürünü yürütmek için kullanılan anahtarı tanımlar.

Oyuncular bunu Kontrollerin içinde her zaman değiştirebilirler.