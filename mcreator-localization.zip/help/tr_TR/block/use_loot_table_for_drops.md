Etkinleştirildiğinde, blok otomatik olarak bir ganimet tablosu oluşturmayacaktır. Bunun yerine, kullanıcının blok düşüşlerini manuel olarak tanımlaması gerekecektir.

Kayıt adı `blocks/${registryname}`, ad alanı _mod_ ve türü _Block_ olan ganimet tablosu mod öğesi oluşturun.

Bu seçenek etkinleştirilmemiş olsa bile ganimet tabloları blok düşüşlerini geçersiz kılabilir.