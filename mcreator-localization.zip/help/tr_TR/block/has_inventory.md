Bu parametre envanterine bir blok verecek. Bu blok varlık sahip olacak.

Bu parametre aşağıdaki gibi özellikleri etkinleştirir:
* Bloktaki NBT etiketleri
* Bloğun öge depolaması için envanter
* Karşılaştırıcı etkileşimi

Bu parametre eğer işaretliyse bu özellik çalışmayacaktır.