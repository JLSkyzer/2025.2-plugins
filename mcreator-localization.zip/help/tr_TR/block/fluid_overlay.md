Bu parametre sadece saydam bloklarla birlikte kullanılmalıdır.

Eğer bu seçenek seçildiyse, bu blok sıvının içinde aynı cam blokları gibi o sıvının texture'ini göstermez.