Bu parametre oyuncunun madencilik yapıp yapamayacağını tanımlar.

Vanilla sürümünden örnekler: Katman kayası ve komut bloğu