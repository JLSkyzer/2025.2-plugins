Bu parametre bloğun yangın tarafından ne kadar sürede yakılacağını belirler.

Vanilla Örnekleri:
* kütüklerin yanıcılık derecesi 5'tir
* tahtaların yanıcılık seviyesi 20'dir