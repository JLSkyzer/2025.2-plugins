Bu parametre işaretliyse, kırmızıtaş tozu her zaman bu bloğa bağlanacaktır (Kırmızıtaş Bloklarına benzer şekilde).

NOT: Bu parametre işaretlenmemiş olsa bile blok yine de kırmızı taş gücü yayabilir.