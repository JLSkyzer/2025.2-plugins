Bloğunuz aşağıdaki durumlarda bu parametreyi işaretleyin:

* katı bir küp değil ya da özel bir şekle sahip,
* ya da bloğun dokusunda görünmez kısımlar varsa.

Eğer bu kutuyu işaretlersen, blok:

* redstone gücünü iletmiyecek,
* oklüzyonu devre dışı bırak,
* görsel vurma kutularının boş olarak ayarlanmasını sağlayın.