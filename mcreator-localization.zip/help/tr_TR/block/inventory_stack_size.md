Bu parametre, dahili envanter yuvalarına yerleştirilebilecek maksimum yığın boyutunu kontrol eder.

Bu parametre ile maksimum öğe yığın boyutu arasındaki daha küçük sayının gerçek maksimum yığın boyutunu belirlediğini unutmayın.