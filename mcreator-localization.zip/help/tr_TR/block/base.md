Blok tabanı kullanılırsa, bazı parametreler devre dışı bırakılabilir veya taban bloğu nedeniyle çalışmayabilir temel bloktan varsayılan değerlere ihtiyaç duyar.

Bu parametreyi yalnızca bunun için iyi bir neden varsa kullanın, çoğu blokta bu ayar olmalıdır Varsayılan temel bloğa.