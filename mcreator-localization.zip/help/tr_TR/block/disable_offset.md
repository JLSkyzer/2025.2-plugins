Blok rastgele bir model ofsetine sahipse, bu seçenek seçilmediği sürece sınırlayıcı kutusu da hareket ettirilecektir. Sınırlayıcı kutu ofset nedeniyle komşu bloklara gömülüyorsa, bunu önlemek için bu kutuyu işaretleyin.

Örneğin bu seçenek bambu için yanlış, uzun otlar için ise doğru olacaktır.