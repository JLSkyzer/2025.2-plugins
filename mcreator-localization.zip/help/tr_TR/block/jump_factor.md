Bu parametre varlıkların atlama yüksekliğini kontrol eder

Blokların çoğunun kullandığı varsayılan değer 1.0'dır. Bal bloğu atlama faktörü 0.5'tir.