Bu blok özelliği tarafından hangi tür değerlerin kabul edilebileceğini tanımlar:

- **Mantık:** _doğru_ veya _yanlış_
- **Tamsayı:** Belirtilen minimum değerden belirtilen maksimum değere kadar olan aralıktaki tam sayılar
- **Enum:** Listelenen metin değerlerinden biri