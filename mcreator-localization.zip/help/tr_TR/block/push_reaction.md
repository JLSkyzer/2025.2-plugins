Bu parametre bloğun pistonla nasıl tepki vereceğini belirler.

* Normal: Stone gibi pistonların normal tepkisi
* Yıkım: Blok bir piston tarafından itildiğinde blok yıkılır.
* Blok: Blok, Obsidian gibi pistona tepki vermiyor.
* Sadece İtme: Blok sadece bir piston tarafından itilebilir.