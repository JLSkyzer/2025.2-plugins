* **Döndürme yok:** Sabit blok yönlendirmesi.
* **Y ekseni dönüşü (S/W/N/E):** Oyuncunun baktığı yöne göre sadece kenarları döndürür.
* **D/U/N/S/W/E dönüşü:** Oyuncunun baktığı yöne göre tüm tarafları döndürür.
* **Y ekseni döndürme (S/W/N/E):** Bloğun tıklandığı blok yüzüne bağlı olarak yalnızca kenarları döndürür.
* **D/U/N/S/W/E döndürme:** Bloğun tıklandığı blok yüzüne göre tüm tarafları döndürür.
* **Log yönü (X/Y/Z):** Bloğu vanilla logları gibi döndürür.