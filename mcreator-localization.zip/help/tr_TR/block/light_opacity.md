Bu özellik, bu bloktan geçerken ışık seviyesinin ne kadar azaldığını belirler. Örneğin, 15 değeri tüm ışığı engeller, 0 değeri ise bloğu ışığa karşı şeffaf hale getirir.
