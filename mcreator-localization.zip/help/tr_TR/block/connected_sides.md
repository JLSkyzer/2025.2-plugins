Bu parametre sadece opak bloklarla kombinasyon oluşturabilir.

Bu, bloğun iç taraflarının cam, buz ve diğer benzer blokların yaptığı gibi birbirine bağlanmasını sağlayacaktır.