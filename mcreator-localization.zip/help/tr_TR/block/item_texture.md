Bu isteğe bağlı özelliktir, bunu açarsanız bloğun envanterdeki dokusunu değiştirecektir.

Genellikle kapılarda veya özel modellerde kullanılır.