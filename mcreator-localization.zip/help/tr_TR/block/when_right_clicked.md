Bir oyuncu bloğa sağ tıkladığında, prosedür başlatılacak.

Prosedür, bir eylem gerçekleştirirse SUCCESS/CONSUME türünde bir eylem sonucu sağlamalı, aksi takdirde PASS sonucu sağlamalıdır. Sağ tıklandığında bir GUI açılırsa veya prosedür herhangi bir değer belirtmezse, eylem sonucu türü BAŞARILI olacaktır.