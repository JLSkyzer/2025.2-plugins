Bu parametre varlıklar bloğun üstündeyken ki hızını kontrol eder.

Blokların çoğunun kullandığı varsayılan değer 1.0'dır. Ruh kumu ve bal bloğunun hız faktörü 0.4'tür.