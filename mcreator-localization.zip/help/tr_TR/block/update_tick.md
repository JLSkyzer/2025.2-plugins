Blok işaretlendiğinde bir prosedürü tetikler.

Doğal olarak ortaya çıkan bloklar, yalnızca performans nedenleriyle rastgele tikleme kullanılıyorsa tikleyecektir.
