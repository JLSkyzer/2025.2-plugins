Rastgele bir prosedürü tetikler.

Bu tetikleyici yalnızca istemci-tarafında tetiklenir, dolayısıyla ses çalma ve parçacık yerleştirme dışında gerçek dünyada hiçbir değişiklik buradan yapılmamalıdır.