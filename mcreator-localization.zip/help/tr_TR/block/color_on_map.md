Bu senin bloğunu haritada gözükeceği renk.

Eğer Varsayılanı işaretlersen, bloğun haritadaki rengi bloğun materialinin rengi olur.

Tüm girdilerin tam RGB renklerini görmek için, Wiki sayfamızı [buradan](https://mcreator.net/wiki/list-block-map-colors) okuyabilirsiniz.