Bu blokla kullanılacak modeli seçin. Model yalnızca görsel görünümü tanımlar ve bloğun hitbox'ını tanımlamaz.

* **Normal** - Her iki tarafında dokular bulunan normal blok
* **Tek doku** - Her tarafında aynı doku bulunan blok
* **Çapraz** - Bitkilerin kullandığı model
* **Mahsul** - Mahsul bitkileri tarafından kullanılan model
* **Çim blok** - Çim blokları tarafından kullanılan model (üst ve yan dokular renklendirilecektir)
* Özel - Özel JSON ve OBJ modelleri de tanımlayabilirsiniz

Özel modeller oluştururken, bu model türüne yönelik vanilla desteği nedeniyle JSON önerilir.