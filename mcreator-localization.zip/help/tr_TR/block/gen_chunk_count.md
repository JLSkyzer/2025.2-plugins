Her parçada ortaya çıkacak ortalama cevher damarı sayısını ayarlar.

Vanilla cevheri grup başına parça değerleri:

* Kömür Cevheri - 20
* Demir Cevheri - 20
* Altın Cevheri - 2
* RedStone Cevheri - 8
* Elmas Cevheri - 1
* Lapis Cevheri - 1