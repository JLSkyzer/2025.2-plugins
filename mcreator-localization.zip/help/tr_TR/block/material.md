Blok malzemesi, pistonlara, suya, bitki yetiştirme seçeneklerine ve daha fazlasına tepki gibi bazı temel blok özelliklerini tanımlar.

Bloğu cevher için kullanmayı düşünüyorsanız, KAYA malzemesini seçin böylece hasat seviyesi düzgün bir şekilde uygulanır.

Malzemeler hakkında daha fazla bilgi edinmek için [buraya](https://mcreator.net/wiki/materials) tıklayın.