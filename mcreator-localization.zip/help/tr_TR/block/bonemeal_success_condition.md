Bu durum, bu blokta kemik unu kullanmanın başarılı olup olmadığını belirler.

Bu false döndürürse, kemik unu tüketilecek, ancak "${l10n.t("elementgui.common.event_on_bonemeal_success")}" prosedürü yürütülmeyecektir.