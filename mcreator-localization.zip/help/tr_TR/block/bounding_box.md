Blok boyutları ve sınırlayıcı kutu, özel bir modelse blok için vuruş alanını ayarlar. Ayrıca, özel bir model kullanılmıyorsa, küp olan bir şeyden normal bir blok boyutunu diğer boyutlara yeniden boyutlandırabilir.

Bu sadece boyutları belirleyecek, şekli değil.

Sınırlayıcı kutu parametrelerinin nasıl çalıştığını anlamak için [buraya](https://mcreator.net/wiki/block-dimensions-and-bonding-box) tıklayın.