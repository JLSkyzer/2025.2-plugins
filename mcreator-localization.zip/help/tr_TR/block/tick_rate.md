Bu parametre bloğun ne sıklıkta işaretleneceğini kontrol eder. Rastgele işaretleme seçilirse, bu parametre hiçbir etkisi yoktur.

Genellikle doğal olarak oluşturulan blokların, rastgele işaretlenmediği sürece varsayılan olarak işaretlenmeyeceğini unutmayın kullanılır.

Varsayılan tik oranının 0 olması bloğun otomatik olarak tik atmayacağı anlamına gelir.

Bu parametre 0'dan büyük bir sayıya ayarlanırsa, blok otomatik olarak tik atacaktır. Bir saniyede 20 dünya tik'i vardır.