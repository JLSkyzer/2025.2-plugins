Bu seçenek işaretlendiğinde varlıklar bloğa tırmanabilecektir.

Bu parametrenin çalışması için bloğun genişliği ve derinliğinin 1'den az olması gerekir, böylece bloğa deydiğini daha düzgün bir şekilde algılanır. Bu parametre kullanılıyorsa bloğun hitbox ayarını buna uyacak şekilde değiştirin.

Orjinal Minecraft'ta olan örnekleri: Merdiven ve Asmalar