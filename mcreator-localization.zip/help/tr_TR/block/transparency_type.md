**Blokunuz şeffaflığa sahipse bu kutuyu işaretleyin** - Sağlam bir blok için işaretlemeden bırakın, bloğunuz yaprak, cam, demir çubuk vb. benziyorsa işaretleyin.

Şeffaflık türleri:

* **Katı:** Şeffaflık yok (toprak, taş vb. gibi)
* **Kesme:** Eşleme olmadan şeffaf (cama benzer)
* **Kesme yontma:** Cutout gibi, ancak mipmapping ile
* **Yarı Saydam:** Kısmen şeffaf ve en ağır kaynak seçeneği (buza benzer)