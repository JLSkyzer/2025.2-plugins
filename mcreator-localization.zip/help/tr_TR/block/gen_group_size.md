Vanilla cevheri grup başına parça değerleri.

Vanilla cevheri grup büyüklükleri:

* Kömür Cevheri - 17
* Demir Cevheri - 9
* Altın Cevheri - 9
* RedStone Cevheri - 8
* Elmas Cevheri - 8
* Lapis Cevheri - 7