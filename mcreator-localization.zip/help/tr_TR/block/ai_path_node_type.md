Bu parametre, bloğun çetelerin yapay zeka yol bulucuları tarafından nasıl "görüleceğini" kontrol eder.

Farklı YZ yol düğümü türleri, aşağıdaki durumlarda hareketin nasıl ilerleyeceğine dair farklı kararlara yol açar AI yolu düğüm tipine bağlı olarak bloğun yakınında.