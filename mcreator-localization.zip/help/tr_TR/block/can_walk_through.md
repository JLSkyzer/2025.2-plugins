Eğer parametre işaretlendiyse oyuncu bu bloğun içinden geçebilir, aynı büyük çimenler ve sarmaşıklar gibi.

Bloğun vurma kutuları olur ama bloğun içinden geçilebilir.