Bu parametre, envanterinizdeki bloğun üzerinde simgenizi tuttuğunuzda bloğa bir ipucu ekler.

Prosedürle oluşturulmuş bir araç ipucu kullanıyorsanız ve bloğunuz bir varlık veya şu anda düşürülmüş bir öğe varlığı tarafından tutulmuyorsa, `varlık` bağımlılığı geçersiz olacaktır.