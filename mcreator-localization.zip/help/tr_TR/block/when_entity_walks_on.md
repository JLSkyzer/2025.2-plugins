Bir varlık bu bloğun üzerinde yürüdüğünde bir prosedürü tetikler.

Varlık gizleniyorsa çağrılmayacaktır.

Yalnızca tam yüksekliğe sahip bloklarla çalışır. Döşemeler, baskı plakaları vb. ile çalışmaz.

Bu gibi durumlarda, bunun yerine çarpışma tetikleyicisini kullanın.