Bu, bu bloğun envanterindeki yuvalara kaç adet öğenin yerleştirilebileceğini gösterir.

Belirli öğeler için belirlenmiş başka bir yuva yığını boyutu sınırı olduğunu unutmayın, bu nedenle bu, öğeler tarafından daha da sınırlanabilen yuvaların üst sınırıdır.