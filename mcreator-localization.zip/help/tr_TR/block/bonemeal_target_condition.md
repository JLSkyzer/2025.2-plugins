Bu durum, bu blokta kemik unu kullanılıp kullanılamayacağını belirler.

Eğer bu yanlış döndürürse kemik tozu tüketilmeyecek ve hiçbir şey olmayacak.