Bu parametre, bloğunuzun dahili envanteri için kaç yuva kullanacağını kontrol eder.

Blok GUI'ye bağlıysa, bu değeri ` GUI'deki en büyük yuva kimliği + 1` olarak ayarlayın