Bu parametre bloğun ne kadar kaygan olduğunu kontrol eder.

Blokların çoğunun kullandığı varsayılan değer 0,6'dır