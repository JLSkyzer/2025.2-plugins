Bu bloğun üretilirken değiştirebileceği blokların listesi.

Bu listeyi boş bırakırsanız, blok doğal olarak üretilmeyecektir çünkü kendisini dünyaya yerleştiremeyecektir.