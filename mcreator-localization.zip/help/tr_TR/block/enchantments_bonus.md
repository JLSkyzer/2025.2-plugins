Bu parametre bloğun büyü masası için sahip olduğu güç bonusunu kontrol eder.

Kitaplığın güç bonusu 1, normal blokların güç bonusu ise 0'dır.