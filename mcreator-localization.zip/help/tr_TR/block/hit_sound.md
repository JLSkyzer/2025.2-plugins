Bu ses oyuncu bloğu kazınca çıkacak.

NOT: Bu ses blok kırılana kadar kendini tekrar etcek.