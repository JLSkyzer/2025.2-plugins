Bu seçenek işaretlendiğinde bloğun içerisine su yerleştirilebilir.

Orjinal Minecraft'ta olan örnekleri: Plakalar, Merdivenler vb.
