Bu parametre, bu bloğun üretebileceği Y yükseklik aralığını kontrol eder.

Vanilla neslinin boy aralıkları:
* Kömür Cevheri - 0 ile 256 arası
* Bakır Cevheri - -16 ile 112 arası
* Demir Cevheri - -32 ile 256 arası
* Altın Cevheri - -64 ile 32 arası
* RedStone Cevheri - -64 ile -32 arası
* Elmas Cevheri - -64 ile 16 arası
* Zümrüt Cevheri - -16 ile 256 arası
* Lapis Cevheri - -64 ile 64 arası