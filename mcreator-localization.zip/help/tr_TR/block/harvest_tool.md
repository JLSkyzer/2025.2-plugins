Bu parametre hangi araçla bu bloğu kırabildiğini kontrol eder.

Cevherler burada kazmayı kullanırken, kütükler balta, topraklar ise kürek kullanır.

Eğer "Belirtilmedi" olarak seçerseniz oyuncu bu bloğu eli ile kırabilir.
