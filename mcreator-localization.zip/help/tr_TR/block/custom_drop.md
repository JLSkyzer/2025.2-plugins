Bu parametre, bu blok çıkarıldığında/kırıldığında bırakılan özel bir öğeyi veya bloğu tanımlar.

Hasat seviyesi kullanılırsa, yalnızca uygun seviyedeki hasat araçları bloğun düşmesini sağlayacaktır.