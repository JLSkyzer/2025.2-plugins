Bu, bu bloğu kırmak için gereken alet seviyesidir.

Yalnızca belirttiğiniz araç kademesi bloğunuzu kırabilecektir.

Özel katmanlar gibi daha fazla kontrol istiyorsanız,
hasat koşulu için özel prosedür kullanın.