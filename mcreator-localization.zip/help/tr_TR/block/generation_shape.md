Oluşturma şekli, bloğun yüksekliğine bağlı olarak bloğun nasıl oluşturulduğunun değiştirilmesine olanak tanır.

* **Tekdüzen**: Bu basit bir dikdörtgendir. Bu Minecraft 1.18'den önce kullanılan şekildi.
* **Üçgen**: Bu şekil blokların üçgen şeklinde oluşmasını sağlar. En fazla şansa sahip katman Bu bloğu elde etmek için minimum ve maksimum yüksekliğin ortası olacaktır. Maksimum ve minimum değerleri unutmayın nesil boyları dünya sınırlarının üstünde veya altında olabilir.