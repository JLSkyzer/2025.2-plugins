Blok kırıldığında ögelerin düşmesini istiyorsanız bu parametreyi işaretleyin.

Örnek: Sandıklar bu parametreyi kullanır.