Eğer emit redstone parametresi işaretliyse, bu parametre yayılan redstone gücünü değiştirmenize olanak tanır.

Bu koşullu prosedür kullanıldığında ve bir sayı döndürüldüğünde, bu blok tarafından yayılan redstone gücü, prosedürün döndürülen sayısı tarafından ayarlanacaktır.

NOT: Redstone bloğa bağlanmasa bile, blok yine de redstone yayabilir.

UYARI: Özel numara sağlayıcı prosedürünü kullanırken, komşularınızı bilgilendirmeniz gerekecektir. değişikliği kaydetmeleri için redstone değer değişikliği blokları.