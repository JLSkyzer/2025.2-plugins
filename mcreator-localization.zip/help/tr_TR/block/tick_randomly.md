Doğal olarak oluşturulan bloklar, rastgele işaretleme kullanılmadığı sürece genellikle varsayılan olarak işaretlenmeyecektir. Doğal olarak oluşturulan bloklar, rastgele işaretleme kullanılmadığı sürece genellikle varsayılan olarak işaretlenmeyecektir.

Bu parametre, hızın global bir dünya tikiyle kontrol edildiği bloğun rastgele tik atmasını sağlar parametre.

Bu tür bir tik, örneğin bitkiler tarafından kullanılır.