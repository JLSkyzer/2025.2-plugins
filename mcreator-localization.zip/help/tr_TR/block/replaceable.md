Bu parametreyi işaretlerseniz, oyuncu başka bir blok yerleştirebilir (bu blok yerleştirilen diğer bloklarla değiştirilebilir).

Örnekler: hava, çoğu bitki