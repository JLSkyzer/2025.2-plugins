Bu parametre, blok yerleşiminin rastgele kaydırılıp kaydırılmayacağını ve hangi eksene göre kaydırılacağını kontrol eder.

Çoğu bitki ofset tiplerinden birini kullanır.