Bloğunuzun işaret ışınına uygulayacağı rengi seçin (kırmızı cam, turuncu cam vb. gibi).

Vanilya kullanımını korumak için VARSAYILAN olarak bırakın (renk değişikliği yok).