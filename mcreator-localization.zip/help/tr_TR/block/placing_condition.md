Bu koşul, bu bloğun belirli bir konuma yerleştirilip yerleştirilemeyeceğini belirler. Konum artık geçerli değilse, blok bir blok güncellemesi aldığında kırılacaktır.

NOT: Bu koşul dünya oluşturma sırasında kontrol edilmez.
