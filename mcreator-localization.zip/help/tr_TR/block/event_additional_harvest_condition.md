Ek hasat koşulunu belirtmek için bu prosedür tetikleyicisini kullanın.
Bloğun hasat edilebilmesi için hem vanilya hem de özel hasat koşullarının sağlanması gerekiyor.

Bu prosedür "hayır" olarak cevaplanırsa blok hasat edilmeyecektir.