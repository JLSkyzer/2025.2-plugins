Bu zırh üzerinde ne kadar yaygın nadir büyü yapılabileceğini belirler. Büyülenebilirlik ne kadar yüksekse, zırhı büyülerken o kadar iyi büyüler elde edersiniz.

Vanilla değerleri:

* Deri Zırh: 15
* Zincir Zırh: 12
* Demir Zırh: 9
* Altın Zırh: 25
* Elmas Zırh: 10
* Netherite Zırh: 15