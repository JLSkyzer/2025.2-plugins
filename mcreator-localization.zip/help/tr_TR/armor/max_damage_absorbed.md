Bu parametre zırh dayanıklılığını tanımlar ve etkili bir şekilde uygulanır:

* kask: emilen_maksimum_hasar * 11
* göğüslük: emilen_maksimum_hasar * 16
* pantolon: emilen_maksimum_hasar * 15
* bot: emilen_maksimum_hasar * 13

Vanilla zırhlar aşağıdaki faktörleri kullanıyor:

* Deri Zırh: 5
* Zincir Zırh: 15
* Demir Zırh: 15
* Altın Zırh: 7
* Elmas Zırh: 33
* Netherite Zırh: 37