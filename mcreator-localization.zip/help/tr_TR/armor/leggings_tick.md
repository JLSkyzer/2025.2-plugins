Bir varlık pantolon taktığında, prosedür her tick'i uygulayacaktır.

Geçirilen varlık zırhı giyen varlıktır, geçirilen istifi zırhın istifi'dir.