Ne zaman varlık üzerine bir bot kuşanmış ise, prosedür her tick'i uygulayacak.

Geçilen varlık üzerine zırh giymiş varlıktı, geçilmiş ürün yığını bir zırh yığınıydı.