Sağlamlık, zırhın korumasını artıracak bir değerdir.

Elmas zırhın dayanıklılığı 2.0'dır (toplam 8.0) ve Netherite zırhının tokluğu 3.0'dır (toplam 12.0).