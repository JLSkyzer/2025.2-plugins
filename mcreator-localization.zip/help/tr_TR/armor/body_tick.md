Ne zaman bir varlık üzerinde zırh kuşanmışsa, prosedür her tick'i uygulayacak.

Geçilen varlık üzerine zırh giymiş varlıktı, geçilmiş ürün yığını bir zırh yığınıydı.