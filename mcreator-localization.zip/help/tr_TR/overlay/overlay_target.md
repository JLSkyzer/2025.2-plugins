Kaplama hedefi, bu kaplamanın hangi ekran üzerine çizileceğini belirtir.

Açlık çubukları ve balkabağı benzeri kaplamalar gibi kaplamalar için Ingame'i kullanın.

Diğer belirli ekranları kaplamak için diğer hedefleri kullanın.