Vanilya olanlar gibi varlığınızı oluşturmak için bu seçeneği değiştirmenize gerek yok.

Ancak, özel yumurtlama koşulları istiyorsanız, yeni bir koşul prosedürü oluşturmanız gerekir.