Vanilla tarzı bir varlık yapmak için bir Vanilla varlık yapay zekası.

Ayrıca düşürülen eşyalar gibi bazı parametreleri de geçersiz kılacaktır.

Genellikle bu parametreden kaçınılmalı ve varsayılan olarak bırakılmalıdır.