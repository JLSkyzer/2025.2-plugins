Varlık baskını kazanırsa bu ses çalınacaktır.

Her Baskıncı, baskının sonunda kendi kutlama sesini çalacaktır.

Varlık bir baskıncı tipi ise ses seçilebilir.