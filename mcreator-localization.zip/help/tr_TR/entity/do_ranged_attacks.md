İşaretlenirse, varlığınız bir fırlatıcıyla saldırır (İskelete benzer). Seçebilirsiniz:
* Listeden kendi fırlatıcınızı seçin (veya varsayılanı kullanın - ok);
* Menzilli saldırılar arasındaki aralık (tik olarak);
* Varlığın, takip menzilinden çıktıktan sonra başka bir varlığı hedef almaya devam edeceği yarıçap.