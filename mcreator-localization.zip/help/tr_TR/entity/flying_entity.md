Bu parametrenin işaretlenmesi bu varlığı uçan bir varlık yapar.

Bu, uçan yol navigatörü ve hareket kontrol cihazına sahip olduğu ve yerçekimi ve düşme hasarının devre dışı bırakıldığı anlamına gelir.