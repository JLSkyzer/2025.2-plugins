Mob olarak ayarlanmış bir canlı varlık saldırabilirken, Creature olarak ayarlanmış bir canlı varlık pasif olacaktır.

Yağmacı, bir baskında ortaya çıkan bir canavardır.

Bu parametre kullanıldığında AI tabanı tarafından geçersiz kılınır.

Burada Yaratık türünü seçerseniz, saldırı AI türlerinin çoğu durumda varlığın oyunu çökertmesine neden olacağını unutmayın.