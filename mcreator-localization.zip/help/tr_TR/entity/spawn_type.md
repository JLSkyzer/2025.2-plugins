Bu parametre, mob'unun ortaya çıkmak üzere tanımlandığı biyomlar için ortaya çıkma türünü kontrol eder.

* Canavar olarak işaretlenmiş bir çete yalnızca karanlıkta veya geceleri ortaya çıkar
* Yaratık olarak işaretlenmiş bir mob, yalnızca <0>minecraft:animals_spawnable_on</0> ile etiketlenmiş bloklarda doğrudan güneş ışığı altında ortaya çıkacaktır. Bu doğma türünü mob türü canlı varlıklarla kullanmayın, çünkü onlar doğmayacaktır.
* Ortam olarak işaretlenmiş bir mob, blok türünün engellemesi dışında her koşulda ortaya çıkacaktır, ancak bu kategori yarasalar gibi oynanış etkisi olmayan moblar için kullanılmalıdır
* Su Yaratığı suda ortaya çıkacaktır, ancak başka bir sınırlama yoktur

Doğma türü sistemi <0>burada</0> derinlemesine açıklanmıştır
