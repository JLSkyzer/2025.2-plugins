İşaretlenirse varlığınız boss olacaktır.

Renk parametresi, çubuk stiline benzer şekilde boss çubuğunun rengini kontrol eder.