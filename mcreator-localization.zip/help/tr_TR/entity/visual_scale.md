Bu özellik, varlığın oyun içindeki görsel model boyutunu kontrol etmenizi sağlar.

Varlığın çarpışma kutusunu ölçeklendirmek için “Bounding box scale” parametresini kullanın.