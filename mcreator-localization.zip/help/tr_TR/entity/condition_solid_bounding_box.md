Bu özellik etkinleştirilirse, varlığın sınırlayıcı kutusu bir bloğun sınırlayıcı kutusuna benzer şekilde hareket edecektir (katı çarpışma).

Minecraft'ın normal versiyonunda tekneler ve shulkerlar tarafından kullanılır.