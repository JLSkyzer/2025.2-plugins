Bu parametre, varlığın oyuncular tarafından kaç blok uzaktan izleneceğini kontrol eder.

Bu parametrenin 0 olarak ayarlanması, varlığın işlenmesini ve çarpışmalarını tamamen devre dışı bırakır.