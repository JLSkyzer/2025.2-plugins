Bu parametrenin işaretlenmesi varlığı bir su varlığı yapar.

Bu parametrenin etkinleştirilmesi, varlığın su tipi bir navigatöre, su hareket kontrol cihazına sahip olmasını sağlar ve dünya oluşturucunun onu sıvılar içinde oluşturmasına izin verir.

Bu, varlığın sıvılar içinde doğmamasını sağlayacaktır.