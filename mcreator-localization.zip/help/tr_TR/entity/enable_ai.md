İşaretlenirse bu, varlık için yapay zeka görevlerini etkinleştirir.

AI görev oluşturucusunda tanımlanan AI görevleri, bu etkinleştirilmediği sürece hiçbir etkiye sahip olmayacaktır.

Bir tür yanlış varlık yapmadığınız sürece, bunun etkin bırakılmasını istersiniz.