Varlığın adım boyunu ayarlar.

Çoğu normal canlı varlığın adım boyu 0,6 iken, atlar gibi binilebilir varlıkların adım boyu 1'dir.