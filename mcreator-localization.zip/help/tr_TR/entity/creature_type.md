Bir yaratığın türünü ayarlamanıza ve belirli değişikliklere neden olmanıza olanak tanır.
* **Ölümsüz**, Keskinlik büyüsünden ekstra hasar alırlar, Anında Hasar ile iyileşirler ve Anında Sağlık ile zarar görürler ve Zehir veya Yenilenmeden etkilenmezler.
* **Eklembacaklılar**, Eklembacaklıların Felaketi büyüsünden ekstra hasar alırlar.
* **Boss** hiç bir iksir efektini almazlar.
* **Su Canlısı** Saplama büyüsünden daha fazla hasar alırlar. 