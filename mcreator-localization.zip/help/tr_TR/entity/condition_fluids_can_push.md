Bu koşul "hayır" olduğunda, varlık sıvılar tarafından itilmeyecektir. Bu genellikle bir su varlığı yaparken istenir.

Canlı varlıklar için varsayılan değer "evet"tir.