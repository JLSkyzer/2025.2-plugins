Bu parametre, kuruluşunuzun dahili envanteri için kaç yuva kullanacağını kontrol eder.

Bu değeri <0> GUI'deki en büyük yuva kimliği + 1</0> olarak ayarlayın.