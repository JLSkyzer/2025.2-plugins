Geri tepme direnci, varlığın saldırı geri tepmesine karşı direncini tanımlar. Genel olarak, vanilya varlıklarının çoğu bunu kullanmaz, ancak referans olarak, yağmacı 0.5'e sahiptir.
