Bu özellik, varlığınızın çarpışma kutusunun boyutunu kontrol etmenizi sağlar.

Varlıkların oyun içi görünümünü ölçeklendirmek için “Model görsel ölçeği” parametresini kullanın.