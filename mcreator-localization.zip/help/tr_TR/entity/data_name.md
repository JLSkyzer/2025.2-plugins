Bu parametre bu değişkenin adını tanımlar.

Genellikle prosedür bloklarıyla birlikte değerini almak veya ayarlamak için kullanılır.