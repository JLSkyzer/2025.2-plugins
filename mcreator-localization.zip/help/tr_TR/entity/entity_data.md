Özel varlığınıza özel değişkenler ekleyin.

Bu değişkenler istemci tarafı ve sunucu tarafı arasında senkronize edilir,
Böylece bunlardan biri, örneğin varlığınızın dokusunu değiştirmek için kullanılabilir.