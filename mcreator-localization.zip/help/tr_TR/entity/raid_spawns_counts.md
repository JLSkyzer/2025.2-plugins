Burada, varlığın her baskın dalgasında kaç kez ortaya çıkacağını ayarlayabilirsiniz.

Zorluğa bağlı olarak belirli sayıda dalga olacaktır:

- Barışçıl: 0
- Kolay: 3
- Normal: 5
- Zor: 7

Baskın dalgası başına oluşan varlık sayısı, varlık bir baskıncı türüyse seçilebilir.