Fırlatılan nesneyi temsil eden öğe dokusu. Burada seçilen öğe ile aynı görünecektir.

Özel şekiller için model parametresini kullanın.