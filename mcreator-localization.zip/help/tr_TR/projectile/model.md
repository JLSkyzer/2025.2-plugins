Atılan nesnenin modeli, menzilli öğenizin modelidir.

Bu parametre kullanıldığında doku parametresi için öğeyi geçersiz kılar.