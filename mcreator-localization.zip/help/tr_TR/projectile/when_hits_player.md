Fırlatılan cisim bir oyuncuya isabet ettiğinde, seçilen prosedürü çalıştıracaktır.

Bu prosedürün, cisim, fırlatılan cisme çarptığında da tetiklenebileceğini unutmayın.