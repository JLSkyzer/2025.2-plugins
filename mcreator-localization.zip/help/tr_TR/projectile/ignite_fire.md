Eğer cisim bir bloğa çarptığında ateş yakmasını istiyorsanız bu parametreyi işaretleyin.

NOT: bu, mobları ateşe vermez