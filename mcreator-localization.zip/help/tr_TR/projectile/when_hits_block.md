Cisim bir bloğa çarptığında, seçilen prosedürü çalıştıracaktır.

İletilen x, y ve z, isabet edilen bloğun koordinatlarıdır.