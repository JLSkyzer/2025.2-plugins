Bu parametre, tarifinizin hangi işçilik sisteminde kullanılabileceğini kontrol eder.

* İşçilik, İşçilik Masasıdır.
* Eritme Fırın tarifidir.
* Patlatma, Yüksek Fırın içindeki bir tariftir.
* Pişirmek, Smoker'ın içindeki bir tariftir.
* Taş kesme bir Taş Kesici tarifidir.
* Kamp ateşinde pişirme, bir Kamp Ateşine sağ tıkladığımızda yapılan bir tariftir.
* Demircilik, Demircilik Masasının içindeki bir tariftir.
* İksir yapma, İksir Standının içindeki bir tariftir.