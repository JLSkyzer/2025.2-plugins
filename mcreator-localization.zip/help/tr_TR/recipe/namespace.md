* Modunuz/veri paketiniz için yeni bir tarif oluşturmak için "Mod" ad alanını kullanın.
* Vanilya tariflerini geçersiz kılmak için "minecraft" kullanın.