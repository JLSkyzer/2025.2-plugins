Bu parametre örs içinde aldığı maliyeti tanımlar.
Parametre büyünün seviyesi ile çarpılır.

Bu parametre yalnızca Minecraft 1.20.6 ve üzeri sürümlerde çalışır.