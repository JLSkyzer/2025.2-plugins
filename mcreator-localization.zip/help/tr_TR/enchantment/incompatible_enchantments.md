Bu parametre, bu büyü ile uyumsuz olan büyüleri tanımlar.
Eğer eşya bu efsunlardan herhangi birine sahipse, bu efsun ona uygulanamaz.
Eğer eşya bu efsunlamaya sahipse, uyumsuz efsunlamalar da ona uygulanamaz.

Bir öğe listesi veya tek bir etiket olarak belirtilebilir. Etiket yalnızca Minecraft 1.21 ve daha yeni sürümlerde düzgün çalışacaktır.