Bu özelliğe sahip büyüler kötüdür (adları kırmızıdır).

Lanet büyüleri eşyalardan kaldırılamaz.