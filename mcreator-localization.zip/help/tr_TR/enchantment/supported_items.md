Büyüyü alabilecek eşyaları belirtin.

Burada belirtilen eşyalar, büyü masasında veya diğer büyüleme yöntemleriyle bu büyüyü alabileceklerdir.

Bir öğe listesi veya tek bir etiket olarak belirtilebilir.