Bu değer, efsununuzun koruyacağı hasar sayısını elde etmek için efsun seviyesiyle (eşyanın o anda sahip olduğu) çarpılacaktır.

Örneğin, KORUMA, 1 değerine sahiptir, bu nedenle ilk seviye için büyü oyuncuyu 1 (seviye) * 1 (değeriniz) = 1 olarak 1 hasara karşı koruyacaktır.