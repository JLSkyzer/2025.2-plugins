Bu parametre büyünün ne kadar yaygın olduğunu tanımlar. Daha küçük değer büyünün daha az yaygın görünmesini sağlar.

Yaygın büyülerin ağırlığı genellikle 10, daha az yaygın olanların ağırlığı 5, nadir olanların ağırlığı 2 ve çok nadir olanların ağırlığı 1'dir.