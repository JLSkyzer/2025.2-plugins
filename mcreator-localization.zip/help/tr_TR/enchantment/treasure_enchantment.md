Bir ganimet büyüsü, büyü masasında elde edilemez.

Yalnızca ganimet tablolarında bulunabilir, örneğin MENDING veya daha yeni olan SOUL SPEED.