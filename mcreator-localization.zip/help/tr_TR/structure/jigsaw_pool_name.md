Bu parametre, belirtilen konumda oluşturulamaması durumunda mevcut havuz tarafından yedek olarak kullanılabilecek bu jigsaw havuzunun adını kontrol eder.

Parçalarınızdaki jigsaw bloklarının “Hedef havuzu” `${modid}:${registryname}_<0>` olarak ayarlanmışsa, oyun bu havuzdan parçaları onlara karşı yerleştirecektir.