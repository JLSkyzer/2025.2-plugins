Bu seçenek, yapı oluşturulurken hangi blokların yerleştirilmeyeceğini (yok sayılacağını) belirtir.

Yapınızın hava bloklarını yerleştirmemek için burada havayı seçin. Bu, yapının çevreyle daha iyi bütünleşmesini sağlayacaktır, ancak mağara tabanlı yapılar söz konusu olduğunda, muhtemelen havayı da yerleştirmek isteyeceksiniz.