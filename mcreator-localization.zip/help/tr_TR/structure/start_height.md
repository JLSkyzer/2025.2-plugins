Etkinleştirildiğinde, yapı belirtilen yükseklik aralığında başlayacaktır.
Bu parametre açık olduğunda, zemin algılama devre dışı bırakılır ve yapısı bunun yerine belirtilen yükseklik aralığına yerleştirilecektir.

Yapının belirli bir yüksekliğe yerleştirilme şansının nasıl dağıtılmasını istediğinize bağlı olarak farklı yükseklik aralığı dağılımları seçebilirsiniz.