Bu parametre arazinin yapıya nasıl uyum sağlayacağını kontrol eder.

* **hiçbiri** - Arazi üzerinde etkisi yoktur.
* **beard_thin** - Yapının altına arazi ekler ve yapının içini kaldırır. Köyler bunu kullanır.
* **beard_box** - Beard_thin'in daha güçlü versiyonu. Antik şehirler bunu kullanır.
* **bury** - Yapının etrafına tamamen arazi ekler. Bu, kalelerin kullandığı şeydir.
* **encapsulate** - Bir yapının her parçasının etrafına yoğunluk eklenecektir. Tamamen yeraltında kaplanması gereken yapılar için idealdir.