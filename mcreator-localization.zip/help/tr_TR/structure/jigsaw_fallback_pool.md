Bu parametre, bir “sonlandırıcı” jigsaw parçası seçmek için mevcut jigsaw havuzu tarafından yedek olarak hangi jigsaw havuzunun kullanılabileceğini belirler
Bu parçadan bir parçanın belirtilen konumda üretilemediği durumlarda (yeterli alan yok veya derinlik sınırına ulaşıldı).

Eğer `${modid}:${registryname}_<0>` olarak ayarlanırsa, oyun bu listedeki `<0>` havuzundan jigsaw parçalarını seçecektir.

Aynı havuz da kullanılabilir, ancak aynı yapının diğer jigsaw parçaları ile çakışırsa, göz ardı edilecektir.