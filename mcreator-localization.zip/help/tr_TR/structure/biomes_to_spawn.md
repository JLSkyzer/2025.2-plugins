Ortaya çıkmanın gerçekleşmesi gereken biyomları tanımlamak için bu alanı kullanın.

Yapıların uygulandıkları biyomları açıkça tanımlamaları gerektiğinden, liste boş olamaz.
