Jigsaw yapınızın parçalarını burada listeleyin. Benzer konumlara yerleştirilmesi amaçlanan parçaları gruplamak için havuzları kullanın.

Parçalarınızdaki jigsaw bloklarının, aşağıda listelenen jigsaw parçalarını yerleştirmeleri gerekiyorsa, hedef havuz adının `${modid}:${registryname}_<0>` olarak ayarlandığından emin olun.