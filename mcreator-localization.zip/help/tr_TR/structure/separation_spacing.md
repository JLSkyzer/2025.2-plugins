Yapılar bir ızgara içinde oluşturulur. Bu iki parametre ızgarayı kontrol eder:

* **separation** - Parçalar halinde minimum mesafe. Aralıktan daha küçük olması gerekir.
* **spacing** - Kabaca bu kümedeki iki yapı arasındaki ortalama mesafe.

<0>aralık = 5</0>, <0>ayrım = 2</0> ile örnek. Her 5x5 yığın ızgarasında bir yapı denemesi olacaktır, ve sadece <0>X</0>'da bir yapı ortaya çıkabilir.

```
.............
..XXX..XXX..X
..XXX..XXX..X
..XXX..XXX..X
.............
.............
..XXX..XXX..X
..XXX..XXX..X
..XXX..XXX..X
```