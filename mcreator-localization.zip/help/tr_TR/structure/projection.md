Bu parametre yapının araziye nasıl uyum sağlayacağını kontrol eder.

Köy yollarında olduğu gibi yapının araziye uymasını istiyorsanız terrain_matching kullanın. Bu, belirli kısımlarda yapının yüksekliğini değiştirecektir.

Rigid, yapıyı olduğu gibi düz bir şekilde yerleştirecektir.