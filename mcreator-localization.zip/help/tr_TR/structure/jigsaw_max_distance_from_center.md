Bu seçenek, bir jigsaw parçasının ana yapıdan ne kadar uzakta oluşturulabileceğini kontrol eder.

İzin verilen maksimum değer arazi adaptasyonu ile daha da kısıtlanır (“yok” olarak ayarlanmadığı sürece) çünkü oyun zemini oluşturulan yapıya göre ayarlamak için biraz alana ihtiyaç duyar.