Enerji elementinin (blok, öge, ...) varsayılan değerini ayarlayın.

Bu, bir oyuncunun elementinizi dünyaya yerleştirdiğinde sahip olacağı enerjidir, element doğal olarak ortaya çıkar veya başka bir şekilde dünyada belirir).