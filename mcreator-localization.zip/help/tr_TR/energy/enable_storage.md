Enerji depolamayı etkinleştirmek için bu seçeneği işaretleyin.

Enerji sisteminin düzgün çalışabilmesi için blokların fayans varlığının etkinleştirilmesi gerekiyor.