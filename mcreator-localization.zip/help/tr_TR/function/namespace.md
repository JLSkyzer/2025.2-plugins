* **Mod:** Sadece sizin modunuz için kullanılır. (Böyle bir fonksiyonu `${modid}:${registryname}` şeklinde çağırın)

* **Minecraft:** Bazı Minecraft seçenekleri ile kullanılır (`minecraft:${registryname}` gibi bir işlev çağırın)