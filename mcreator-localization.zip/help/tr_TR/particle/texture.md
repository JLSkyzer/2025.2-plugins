Doku döşenmiş bir dokuysa (dikey bir şeritte birden fazla doku), doku, şeritteki olası karolardan birinden rastgele seçilecektir.

Animasyonlu doku parametresi etkinleştirildiğinde, parçacık doku karoları dizisinde animasyonlu olacaktır.

ÖNEMLİ: Doku adı elemanın kayıt adından farklıysa, dokunun bir kopyası oluşturulacaktır.