Bu parametre parçacığın ilk dönme hızını kontrol eder. Negatif değerler saat yönünün tersine dönme anlamına gelir.

0,314 değeri kabaca saniyede 1 dönüş ile aynıdır.