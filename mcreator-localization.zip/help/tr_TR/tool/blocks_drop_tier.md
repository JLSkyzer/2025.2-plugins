Bu, bu aracın olduğu kademedir. Hangi blokları başarıyla toplayabileceğini tanımlar.

Özel kademeler ve hasat kuralları gibi daha fazla kontrol istiyorsanız, ek bir düşme koşulu için özel prosedür kullanın.