Ek alet düşürme/ hasat koşulu belirtmek için bu prosedür tetikleyicisini kullanın.
Bloğun bu araç kullanılarak hasat edilmesi için hem vanilla hem de özel hasat koşulunun karşılanması gerekir.

Bu prosedür false değerini verirse, araç blok düşüşünü hasat etmeyecektir.