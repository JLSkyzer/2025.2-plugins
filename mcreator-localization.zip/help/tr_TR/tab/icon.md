Kırmızı taş sekmesi için kırmızı taş tozu gibi yaratıcı sekmeyi tanımlayan simge.

Burada yalnızca öğeler desteklenir. Öğesi olmayan bloklar simge olarak gösterilemez.
