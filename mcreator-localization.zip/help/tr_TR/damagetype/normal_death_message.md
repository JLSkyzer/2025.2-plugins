Bu mesaj, çoğu durumda bir oyuncu bu tür bir hasardan öldüğünde sohbette görüntülenir.

Mesajda aşağıdaki belirteçleri kullanabilirsiniz:

- `<player>`: ölen oyuncunun adı
- `<attacker>`: hasarı veren varlığın adı

NOT: İkinci belirteci yalnızca hasar her zaman bir yaratık tarafından veriliyorsa kullanın.