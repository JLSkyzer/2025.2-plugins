Bu parametre, hasar verildiğinde oyuncuya ne kadar yorgunluk uygulanacağını belirler.

Değer yükseldikçe açlık çubuğu daha hızlı düşüş yaşar.