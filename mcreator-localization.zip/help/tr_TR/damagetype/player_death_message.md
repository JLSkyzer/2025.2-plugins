Bu mesaj, bir oyuncu bu tür bir hasar nedeniyle öldüğünde ancak yakın zamanda başka bir varlık tarafından yaralandığında sohbette görüntülenir.

Mesajda aşağıdaki belirteçleri (değişkenleri) kullanabilirsiniz:

- `<player>`: ölen oyuncunun adı
- `<attacker>`: hasarı veren varlığın adı