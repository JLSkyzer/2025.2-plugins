Bu mesaj, oluşturduğunuz canlı tarafından bir oyuncu öldürüldüğünde sohbet kısmında görüntülenecekir. Ayrıca canlının elinde bulunan nesneye göre mesajı özelleştirebilirsiniz.

Mesajda aşağıdaki belirteçleri (değişkenleri) kullanabilirsiniz:

- `<player>`: ölen oyuncunun adı
- `<attacker>`: hasarı veren canlının adı
- `<item>`: saldırganın elinde tuttuğu ögenin adı