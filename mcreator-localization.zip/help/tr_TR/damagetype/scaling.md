Bu parametre, verilen hasarın zorluk seviyesine göre artıp artmayacağını belirler.

- `asla`: zorluk verilen hasarı etkilemez
- `her zaman`: zorluk, kaynağı ne olursa olsun verilen hasarı her zaman artırır
- `when_caused_by_living_non_player`: zorluk, yalnızca canlı bir varlıktan kaynaklanıyorsa verilen hasarı artırır
  (iskeletler veya örümcekler gibi)