Sıvı depolamayı etkinleştirmek için bu seçeneği işaretleyin.

Sıvı tankı sisteminin düzgün çalışması için blokların döşeme varlığının etkinleştirilmiş olması gerekir.